import { useState, useRef } from 'react'

export default function UploadPanel({ onUpload, loading }) {
  const [dragging, setDragging] = useState(false)
  const inputRef = useRef(null)

  function handleFiles(files) {
    if (files && files[0]) onUpload(files[0])
  }

  return (
    <div
      className={`upload-panel ${dragging ? 'dragging' : ''}`}
      onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault()
        setDragging(false)
        handleFiles(e.dataTransfer.files)
      }}
    >
      <p>Drop a CSV or JSON log file here, or</p>
      <button className="btn btn-primary" onClick={() => inputRef.current.click()} disabled={loading}>
        {loading ? <span className="spinner" /> : 'Choose log file'}
      </button>
      <input
        ref={inputRef}
        type="file"
        accept=".csv,.json,.log,.txt"
        style={{ display: 'none' }}
        onChange={(e) => handleFiles(e.target.files)}
      />
      <div className="sample-links">
        no logs handy? try{' '}
        <button onClick={() => onUpload(null, 'sample_logs.csv')}>sample_logs.csv</button>
        or
        <button onClick={() => onUpload(null, 'sample_logs.json')}>sample_logs.json</button>
      </div>
    </div>
  )
}

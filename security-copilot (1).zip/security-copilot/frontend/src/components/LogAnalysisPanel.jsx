import { useState, useMemo } from 'react'

export default function LogAnalysisPanel({ events }) {
  const [query, setQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')

  const filtered = useMemo(() => {
    return events.filter((e) => {
      if (statusFilter !== 'all') {
        const status = String(e.status || '').toLowerCase()
        const isFail = ['fail', 'failed', 'failure', 'denied', 'false', 'error', '403', '401'].includes(status)
        if (statusFilter === 'failed' && !isFail) return false
        if (statusFilter === 'success' && isFail) return false
      }
      if (!query.trim()) return true
      const haystack = `${e.source_ip} ${e.user} ${e.event_type} ${e.status} ${e.message}`.toLowerCase()
      return haystack.includes(query.toLowerCase())
    })
  }, [events, query, statusFilter])

  function isFailStatus(status) {
    const s = String(status || '').toLowerCase()
    return ['fail', 'failed', 'failure', 'denied', 'false', 'error', '403', '401'].includes(s)
  }

  return (
    <div>
      <div className="log-toolbar">
        <input
          className="log-search"
          placeholder="Search by IP, user, event type, or message..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select className="log-select" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="all">All statuses</option>
          <option value="failed">Failed / denied only</option>
          <option value="success">Success only</option>
        </select>
      </div>

      <div className="log-table-wrap">
        <table className="log-table">
          <thead>
            <tr>
              <th>Timestamp</th>
              <th>Source IP</th>
              <th>User</th>
              <th>Event type</th>
              <th>Status</th>
              <th>Message</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((e, i) => (
              <tr key={i}>
                <td>{e.timestamp || '—'}</td>
                <td>{e.source_ip || '—'}</td>
                <td>{e.user || '—'}</td>
                <td>{e.event_type || '—'}</td>
                <td className={isFailStatus(e.status) ? 'status-fail' : 'status-ok'}>{e.status || '—'}</td>
                <td title={e.message}>{e.message || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="log-count-note">
        showing {filtered.length} of {events.length} events
      </div>
    </div>
  )
}

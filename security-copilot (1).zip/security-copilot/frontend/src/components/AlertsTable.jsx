import { useState } from 'react'
import { summarizeAlert } from '../api'

function AlertRow({ alert, onUpdate }) {
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  async function handleSummarize() {
    setLoading(true)
    setError(null)
    try {
      const updated = await summarizeAlert(alert.id)
      onUpdate(updated)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="alert-card">
      <div className="alert-row" onClick={() => setOpen(!open)}>
        <span className={`severity-dot ${alert.severity}`} />
        <span className="alert-title">{alert.title}</span>
        <span className="alert-meta">{alert.events.length} event{alert.events.length !== 1 ? 's' : ''}</span>
      </div>
      {open && (
        <div className="alert-detail">
          <p>{alert.description}</p>

          {alert.ai_summary ? (
            <div className="ai-summary">
              <span className="label">Explanation</span>
              {alert.ai_summary}
              {alert.ai_action && <div className="action">→ {alert.ai_action}</div>}
            </div>
          ) : (
            <button className="btn btn-ghost" onClick={handleSummarize} disabled={loading}>
              {loading ? <span className="spinner" /> : 'Explain this alert'}
            </button>
          )}
          {error && <p style={{ color: 'var(--red)', marginTop: 8 }}>{error}</p>}
        </div>
      )}
    </div>
  )
}

export default function AlertsTable({ alerts, onUpdateAlert }) {
  if (alerts.length === 0) {
    return <div className="empty-state">No alerts triggered — this log looks clean.</div>
  }

  const sorted = [...alerts].sort((a, b) => {
    const rank = { critical: 0, high: 1, medium: 2, low: 3 }
    return (rank[a.severity] ?? 4) - (rank[b.severity] ?? 4)
  })

  return (
    <div className="alerts-section">
      <h2>Alerts</h2>
      {sorted.map((a) => (
        <AlertRow key={a.id} alert={a} onUpdate={onUpdateAlert} />
      ))}
    </div>
  )
}

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts'
import StatsBar from './StatsBar.jsx'

const SEVERITY_COLORS = { high: '#E5484D', critical: '#E5484D', medium: '#F2A93B', low: '#4FD8CE' }

function severityBreakdown(alerts) {
  const counts = { high: 0, medium: 0, low: 0 }
  alerts.forEach((a) => {
    const s = a.severity === 'critical' ? 'high' : a.severity
    if (counts[s] !== undefined) counts[s] += 1
  })
  return Object.entries(counts)
    .filter(([, v]) => v > 0)
    .map(([name, value]) => ({ name, value }))
}

function eventsByHour(events) {
  const buckets = {}
  events.forEach((e) => {
    const ts = e.timestamp
    if (!ts) return
    const hour = String(ts).slice(11, 13) || '??'
    buckets[hour] = (buckets[hour] || 0) + 1
  })
  return Object.entries(buckets)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([hour, count]) => ({ hour: `${hour}:00`, count }))
}

function topIps(events, limit = 5) {
  const counts = {}
  events.forEach((e) => {
    if (e.source_ip) counts[e.source_ip] = (counts[e.source_ip] || 0) + 1
  })
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
}

export default function DashboardPanel({ result }) {
  const { events, alerts, overview } = result
  const severityData = severityBreakdown(alerts)
  const hourlyData = eventsByHour(events)
  const ips = topIps(events)

  return (
    <div>
      <StatsBar eventCount={result.event_count} alerts={alerts} />

      <div className="overview-box">
        <span className="overview-label">Overview</span>
        {overview}
      </div>

      <div className="dashboard-grid">
        <div className="chart-card">
          <h3>Events over time (by hour)</h3>
          {hourlyData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={hourlyData}>
                <CartesianGrid stroke="#232E3A" vertical={false} />
                <XAxis dataKey="hour" stroke="#7C8B9C" fontSize={11} />
                <YAxis stroke="#7C8B9C" fontSize={11} allowDecimals={false} />
                <Tooltip contentStyle={{ background: '#171F28', border: '1px solid #232E3A', fontSize: 12 }} />
                <Bar dataKey="count" fill="#4FD8CE" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p style={{ color: 'var(--muted)', fontSize: 13 }}>No timestamped events to chart.</p>
          )}
        </div>

        <div className="chart-card">
          <h3>Alert severity breakdown</h3>
          {severityData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={severityData} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={3}>
                  {severityData.map((entry) => (
                    <Cell key={entry.name} fill={SEVERITY_COLORS[entry.name]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: '#171F28', border: '1px solid #232E3A', fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <p style={{ color: 'var(--muted)', fontSize: 13 }}>No alerts to break down.</p>
          )}
        </div>
      </div>

      <div className="chart-card">
        <h3>Top source IPs</h3>
        {ips.length > 0 ? (
          <ul className="top-ip-list">
            {ips.map(([ip, count]) => (
              <li key={ip}>
                <span>{ip}</span>
                <span className="top-ip-count">{count} events</span>
              </li>
            ))}
          </ul>
        ) : (
          <p style={{ color: 'var(--muted)', fontSize: 13 }}>No source IPs found in this log.</p>
        )}
      </div>
    </div>
  )
}

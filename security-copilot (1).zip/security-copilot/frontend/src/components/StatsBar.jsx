export default function StatsBar({ eventCount, alerts }) {
  const high = alerts.filter((a) => a.severity === 'high' || a.severity === 'critical').length
  const medium = alerts.filter((a) => a.severity === 'medium').length
  const low = alerts.filter((a) => a.severity === 'low').length

  return (
    <div className="stats-bar">
      <div className="stat-card">
        <div className="stat-value">{eventCount}</div>
        <div className="stat-label">Events scanned</div>
      </div>
      <div className="stat-card risk-high">
        <div className="stat-value">{high}</div>
        <div className="stat-label">High severity</div>
      </div>
      <div className="stat-card risk-medium">
        <div className="stat-value">{medium}</div>
        <div className="stat-label">Medium severity</div>
      </div>
      <div className="stat-card risk-low">
        <div className="stat-value">{low}</div>
        <div className="stat-label">Low severity</div>
      </div>
    </div>
  )
}

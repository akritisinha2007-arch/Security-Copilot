const BASE = '/api'

export async function uploadLog(file) {
  const formData = new FormData()
  formData.append('file', file)
  const res = await fetch(`${BASE}/upload`, { method: 'POST', body: formData })
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.detail || 'Upload failed')
  }
  return res.json()
}

export async function summarizeAlert(alertId) {
  const res = await fetch(`${BASE}/alerts/${alertId}/summarize`, { method: 'POST' })
  if (!res.ok) {
    const err = await res.json().catch(() => ({}))
    throw new Error(err.detail || 'Summarize failed')
  }
  return res.json()
}

import { useState } from 'react'
import UploadPanel from './components/UploadPanel.jsx'
import DashboardPanel from './components/DashboardPanel.jsx'
import LogAnalysisPanel from './components/LogAnalysisPanel.jsx'
import AlertsTable from './components/AlertsTable.jsx'
import AISummaryPanel from './components/AISummaryPanel.jsx'
import { uploadLog } from './api'

const TABS = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'logs', label: 'Log Analysis' },
  { id: 'threats', label: 'Threat Detection' },
  { id: 'ai', label: 'AI Summary' },
]

export default function App() {
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [tab, setTab] = useState('dashboard')

  async function handleUpload(file, sampleName) {
    setLoading(true)
    setError(null)
    try {
      let toUpload = file
      if (!toUpload && sampleName) {
        const res = await fetch(`/${sampleName}`)
        const blob = await res.blob()
        toUpload = new File([blob], sampleName)
      }
      const data = await uploadLog(toUpload)
      setResult(data)
      setTab('dashboard')
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  function handleUpdateAlert(updated) {
    setResult((prev) => ({
      ...prev,
      alerts: prev.alerts.map((a) => (a.id === updated.id ? updated : a)),
    }))
  }

  return (
    <div className="app">
      <header className="header">
        <div className="header-row">
          <div className="brand">
            <span className="brand-mark">SIGNAL</span>
            <h1>AI Security Copilot</h1>
          </div>
          <span className="brand-sub">log analysis · anomaly detection · plain-english summaries</span>
        </div>
      </header>

      <main className="main">
        <UploadPanel onUpload={handleUpload} loading={loading} />

        {error && <div className="error-banner">{error}</div>}

        {result && (
          <>
            <nav className="tab-nav">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  className={`tab-btn ${tab === t.id ? 'active' : ''}`}
                  onClick={() => setTab(t.id)}
                >
                  {t.label}
                  {t.id === 'threats' && <span className="tab-badge">{result.alerts.length}</span>}
                  {t.id === 'logs' && <span className="tab-badge">{result.event_count}</span>}
                </button>
              ))}
            </nav>

            {tab === 'dashboard' && <DashboardPanel result={result} />}
            {tab === 'logs' && <LogAnalysisPanel events={result.events} />}
            {tab === 'threats' && <AlertsTable alerts={result.alerts} onUpdateAlert={handleUpdateAlert} />}
            {tab === 'ai' && (
              <AISummaryPanel result={result} onUpdateAlert={handleUpdateAlert} aiEnabled={result.ai_enabled} />
            )}
          </>
        )}
      </main>
    </div>
  )
}

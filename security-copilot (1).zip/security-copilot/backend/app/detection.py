"""
Beginner-friendly rule-based detection engine.

Each rule looks at the normalized events and returns a list of alert dicts:
    {
        "rule": "brute_force",
        "severity": "high" | "medium" | "low",
        "title": "...",
        "description": "...",
        "events": [ ...the matching raw events... ],
    }

Nothing here is machine learning - it's plain, readable logic so it's easy
to understand and extend. The AI layer (summarizer.py) is what turns these
raw alerts into a friendly written summary.
"""
from collections import defaultdict
from datetime import datetime
from typing import List, Dict, Any

SUSPICIOUS_KEYWORDS = [
    "malware", "exploit", "sql injection", "sqlmap", "xss", "ransomware",
    "trojan", "backdoor", "privilege escalation", "unauthorized", "brute force",
    "port scan", "nmap", "reverse shell", "credential dump",
]

FAILURE_STATUS_VALUES = {"fail", "failed", "failure", "denied", "false", "error", "403", "401"}


def _try_parse_time(ts):
    if not ts:
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f",
                "%m/%d/%Y %H:%M:%S", "%d/%m/%Y %H:%M:%S"):
        try:
            return datetime.strptime(str(ts)[:26], fmt)
        except ValueError:
            continue
    return None


def _is_failure(event) -> bool:
    status = str(event.get("status") or "").strip().lower()
    event_type = str(event.get("event_type") or "").strip().lower()
    return status in FAILURE_STATUS_VALUES or "fail" in event_type or "denied" in event_type


def detect_brute_force(events: List[Dict[str, Any]], threshold: int = 5) -> List[Dict[str, Any]]:
    """Flags any source IP or user with >= threshold failed logins."""
    alerts = []
    by_ip = defaultdict(list)
    by_user = defaultdict(list)

    for e in events:
        if _is_failure(e):
            if e.get("source_ip"):
                by_ip[e["source_ip"]].append(e)
            if e.get("user"):
                by_user[e["user"]].append(e)

    for ip, matches in by_ip.items():
        if len(matches) >= threshold:
            alerts.append({
                "rule": "brute_force_ip",
                "severity": "high",
                "title": f"Possible brute-force from {ip}",
                "description": f"{len(matches)} failed login attempts from IP {ip}.",
                "events": matches,
            })

    for user, matches in by_user.items():
        if len(matches) >= threshold:
            alerts.append({
                "rule": "brute_force_user",
                "severity": "high",
                "title": f"Repeated failed logins for user '{user}'",
                "description": f"{len(matches)} failed login attempts targeting account '{user}'.",
                "events": matches,
            })

    return alerts


def detect_suspicious_keywords(events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Flags any event whose message contains a known-bad keyword."""
    alerts = []
    for e in events:
        text = " ".join(str(v) for v in [e.get("message"), e.get("event_type")] if v).lower()
        for kw in SUSPICIOUS_KEYWORDS:
            if kw in text:
                alerts.append({
                    "rule": "suspicious_keyword",
                    "severity": "high",
                    "title": f"Suspicious activity keyword detected: '{kw}'",
                    "description": f"Event mentions '{kw}', which often indicates malicious activity.",
                    "events": [e],
                })
                break
    return alerts


def detect_off_hours_access(events: List[Dict[str, Any]], start_hour=0, end_hour=5) -> List[Dict[str, Any]]:
    """Flags successful logins that happened late at night (00:00-05:00 by default)."""
    alerts = []
    for e in events:
        if _is_failure(e):
            continue
        event_type = str(e.get("event_type") or "").lower()
        if "login" not in event_type and "auth" not in event_type:
            continue
        dt = _try_parse_time(e.get("timestamp"))
        if dt and start_hour <= dt.hour < end_hour:
            alerts.append({
                "rule": "off_hours_login",
                "severity": "medium",
                "title": f"Login at unusual hour ({dt.strftime('%H:%M')})",
                "description": f"User '{e.get('user') or 'unknown'}' logged in from {e.get('source_ip') or 'unknown IP'} at {dt}.",
                "events": [e],
            })
    return alerts


def detect_event_burst(events: List[Dict[str, Any]], window_events: int = 20, per_ip_threshold: int = 15) -> List[Dict[str, Any]]:
    """Flags an IP responsible for an unusually large share of total traffic (possible scan/DoS)."""
    alerts = []
    if len(events) < window_events:
        return alerts
    counts = defaultdict(int)
    for e in events:
        if e.get("source_ip"):
            counts[e["source_ip"]] += 1
    for ip, count in counts.items():
        if count >= per_ip_threshold:
            matches = [e for e in events if e.get("source_ip") == ip]
            alerts.append({
                "rule": "event_burst",
                "severity": "medium",
                "title": f"High volume of events from {ip}",
                "description": f"{count} events from a single IP ({ip}) - could indicate scanning or automated activity.",
                "events": matches,
            })
    return alerts


def run_all_detections(events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    alerts = []
    alerts += detect_brute_force(events)
    alerts += detect_suspicious_keywords(events)
    alerts += detect_off_hours_access(events)
    alerts += detect_event_burst(events)
    return alerts

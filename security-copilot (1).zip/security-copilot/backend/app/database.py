"""Minimal SQLite persistence - beginner friendly, no ORM needed."""
import sqlite3
import json
import os
from datetime import datetime, timezone

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "copilot.db")


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT,
            uploaded_at TEXT,
            event_count INTEGER,
            overview TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id INTEGER,
            rule TEXT,
            severity TEXT,
            title TEXT,
            description TEXT,
            events_json TEXT,
            ai_summary TEXT,
            ai_action TEXT,
            FOREIGN KEY (run_id) REFERENCES runs (id)
        )
    """)
    conn.commit()
    conn.close()


def save_run(filename: str, event_count: int, alerts: list, overview: str) -> int:
    conn = get_conn()
    cur = conn.execute(
        "INSERT INTO runs (filename, uploaded_at, event_count, overview) VALUES (?, ?, ?, ?)",
        (filename, datetime.now(timezone.utc).isoformat(), event_count, overview),
    )
    run_id = cur.lastrowid
    for a in alerts:
        conn.execute(
            "INSERT INTO alerts (run_id, rule, severity, title, description, events_json) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (run_id, a["rule"], a["severity"], a["title"], a["description"],
             json.dumps(a.get("events", []), default=str)),
        )
    conn.commit()
    conn.close()
    return run_id


def get_runs():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM runs ORDER BY id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_alerts_for_run(run_id: int):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM alerts WHERE run_id = ? ORDER BY id", (run_id,)).fetchall()
    conn.close()
    result = []
    for r in rows:
        d = dict(r)
        d["events"] = json.loads(d.pop("events_json"))
        result.append(d)
    return result


def get_alert(alert_id: int):
    conn = get_conn()
    row = conn.execute("SELECT * FROM alerts WHERE id = ?", (alert_id,)).fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d["events"] = json.loads(d.pop("events_json"))
    return d


def save_alert_ai_summary(alert_id: int, summary: str, action: str, severity: str):
    conn = get_conn()
    conn.execute(
        "UPDATE alerts SET ai_summary = ?, ai_action = ?, severity = ? WHERE id = ?",
        (summary, action, severity, alert_id),
    )
    conn.commit()
    conn.close()

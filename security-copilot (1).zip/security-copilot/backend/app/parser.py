"""
Turns messy CSV/JSON log files into a list of normalized events.

A normalized event always has these keys (missing values become None):
    timestamp, source_ip, user, event_type, status, message
"""
import csv
import json
import io
from datetime import datetime
from typing import List, Dict, Any

# Common alternate names we might see for each field, lowercased.
FIELD_ALIASES = {
    "timestamp": ["timestamp", "time", "date", "datetime", "@timestamp", "ts"],
    "source_ip": ["source_ip", "ip", "src_ip", "client_ip", "remote_addr", "ip_address"],
    "user": ["user", "username", "account", "login", "user_id"],
    "event_type": ["event_type", "event", "action", "type", "category"],
    "status": ["status", "result", "outcome", "success"],
    "message": ["message", "msg", "description", "details", "raw"],
}


def _pick(raw: Dict[str, Any], canonical_field: str):
    """Find the first matching alias for a canonical field in a raw log row."""
    lower_map = {k.lower().strip(): v for k, v in raw.items()}
    for alias in FIELD_ALIASES[canonical_field]:
        if alias in lower_map:
            return lower_map[alias]
    return None


def _normalize_row(raw: Dict[str, Any]) -> Dict[str, Any]:
    event = {field: _pick(raw, field) for field in FIELD_ALIASES}
    # Keep the original row too, in case the UI/AI wants extra context.
    event["raw"] = raw
    return event


def parse_log_file(filename: str, content: bytes) -> List[Dict[str, Any]]:
    """Parse a CSV or JSON log file into a list of normalized events."""
    text = content.decode("utf-8", errors="replace")

    if filename.lower().endswith(".json"):
        data = json.loads(text)
        rows = data if isinstance(data, list) else data.get("logs", data.get("events", [data]))
    else:
        # Treat everything else (including .log/.txt) as CSV first, fall back to
        # one-event-per-line plain text.
        try:
            reader = csv.DictReader(io.StringIO(text))
            rows = list(reader)
            if not rows or reader.fieldnames is None:
                raise ValueError("not really csv")
        except Exception:
            rows = [{"message": line.strip()} for line in text.splitlines() if line.strip()]

    events = [_normalize_row(row) for row in rows]
    return events

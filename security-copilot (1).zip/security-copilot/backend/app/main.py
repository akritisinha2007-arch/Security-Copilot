from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from . import parser, detection, summarizer, database

app = FastAPI(title="AI Security Copilot")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # fine for local dev; lock this down before deploying
    allow_methods=["*"],
    allow_headers=["*"],
)

database.init_db()


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/upload")
async def upload_log(file: UploadFile = File(...)):
    """Upload a CSV or JSON log file. Parses it, runs detection rules,
    generates an AI overview, and stores the results."""
    content = await file.read()
    try:
        events = parser.parse_log_file(file.filename, content)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not parse file: {e}")

    if not events:
        raise HTTPException(status_code=400, detail="No events found in file.")

    alerts = detection.run_all_detections(events)
    overview = summarizer.summarize_overview(alerts)
    run_id = database.save_run(file.filename, len(events), alerts, overview)

    return {
        "run_id": run_id,
        "event_count": len(events),
        "alert_count": len(alerts),
        "overview": overview,
        "alerts": database.get_alerts_for_run(run_id),
        "events": events,
        "ai_enabled": summarizer.AI_ENABLED,
    }


@app.get("/api/runs")
def list_runs():
    return database.get_runs()


@app.get("/api/runs/{run_id}/alerts")
def list_alerts(run_id: int):
    return database.get_alerts_for_run(run_id)


@app.post("/api/alerts/{alert_id}/summarize")
def summarize_one(alert_id: int):
    """Ask Claude to explain a single alert in plain English."""
    alert = database.get_alert(alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")

    if alert.get("ai_summary"):
        return alert  # already summarized, avoid re-spending tokens

    result = summarizer.summarize_alert(alert)

    database.save_alert_ai_summary(
        alert_id,
        result.get("summary", ""),
        result.get("recommended_action", ""),
        result.get("severity", alert["severity"]),
    )
    return database.get_alert(alert_id)

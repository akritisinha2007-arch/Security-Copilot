"""
Turns a raw rule-based alert into a short, plain-English summary a
non-expert can understand, plus a recommended next action.

If ANTHROPIC_API_KEY is set (see .env.example), summaries are generated
live by Claude. If no key is set, hand-written template summaries are
used instead - the app works fully offline either way, no API key required.
"""
import os
import json
from anthropic import Anthropic

_client = None
AI_ENABLED = bool(os.environ.get("ANTHROPIC_API_KEY"))


def _get_client() -> Anthropic:
    global _client
    if _client is None:
        _client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    return _client


# ---------------------------------------------------------------------------
# Template fallback - used automatically whenever no API key is configured.
# Each template is a function of (alert) -> {summary, severity, recommended_action}
# ---------------------------------------------------------------------------

def _fmt_list(values, limit=3):
    values = [str(v) for v in values if v]
    if not values:
        return "an unknown source"
    shown = values[:limit]
    extra = f" and {len(values) - limit} more" if len(values) > limit else ""
    return ", ".join(shown) + extra


def _template_brute_force(alert):
    events = alert.get("events", [])
    ips = _fmt_list({e.get("source_ip") for e in events})
    users = _fmt_list({e.get("user") for e in events})
    count = len(events)
    return {
        "summary": (
            f"There were {count} failed login attempts involving IP(s) {ips} and "
            f"user(s) {users}. This pattern - many failed logins in a short window - "
            f"usually means someone (or some automated tool) is guessing passwords, "
            f"commonly called a 'brute-force' attack."
        ),
        "severity": "high",
        "recommended_action": (
            "Temporarily block the source IP, force a password reset for the "
            "targeted account, and enable multi-factor authentication if it isn't already on."
        ),
    }


def _template_suspicious_keyword(alert):
    events = alert.get("events", [])
    sample = events[0] if events else {}
    return {
        "summary": (
            f"An event was logged containing wording that often indicates malicious "
            f"activity: \"{sample.get('message', alert.get('description', ''))}\". "
            f"This doesn't automatically confirm an attack, but it's worth a closer look."
        ),
        "severity": "high",
        "recommended_action": (
            "Review the full event details and surrounding log entries manually to "
            "confirm whether this was a genuine attack attempt or a false positive."
        ),
    }


def _template_off_hours(alert):
    events = alert.get("events", [])
    sample = events[0] if events else {}
    return {
        "summary": (
            f"User '{sample.get('user', 'unknown')}' logged in from "
            f"{sample.get('source_ip', 'an unknown IP')} at an unusual hour "
            f"(between midnight and 5am). Logins outside normal working hours are "
            f"sometimes legitimate (remote workers, different time zones) but can "
            f"also indicate a compromised account."
        ),
        "severity": "medium",
        "recommended_action": (
            "Confirm with the account owner whether this login was expected. If not, "
            "reset the account's password and review what the account accessed."
        ),
    }


def _template_event_burst(alert):
    events = alert.get("events", [])
    ip = events[0].get("source_ip") if events else "unknown"
    return {
        "summary": (
            f"A single source ({ip}) generated {len(events)} events, a much higher "
            f"volume than typical traffic. This pattern often shows up during "
            f"automated scanning, bots, or denial-of-service activity."
        ),
        "severity": "medium",
        "recommended_action": (
            "Check whether this IP is a known/trusted service. If not, consider rate-limiting "
            "or blocking it at the firewall level."
        ),
    }


_TEMPLATES = {
    "brute_force_ip": _template_brute_force,
    "brute_force_user": _template_brute_force,
    "suspicious_keyword": _template_suspicious_keyword,
    "off_hours_login": _template_off_hours,
    "event_burst": _template_event_burst,
}


def _template_alert_summary(alert: dict) -> dict:
    fn = _TEMPLATES.get(alert.get("rule"))
    if fn:
        return fn(alert)
    return {
        "summary": alert.get("description", "No further detail available."),
        "severity": alert.get("severity", "medium"),
        "recommended_action": "Review the raw event details manually.",
    }


MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")

SYSTEM_PROMPT = """You are a security analyst assistant helping a beginner understand \
log alerts. Given a raw detection alert (JSON), respond with ONLY a JSON object, no \
markdown fences, no preamble, with these exact keys:

{
  "summary": "1-3 plain-English sentences explaining what happened and why it matters, written for someone new to security",
  "severity": "low" | "medium" | "high" | "critical",
  "recommended_action": "1-2 concrete next steps the user should take"
}

Be concrete and reference specific details from the alert (IPs, usernames, counts) when relevant. \
Do not invent details that aren't in the alert data."""


def _ai_summarize_alert(alert: dict) -> dict:
    """Send one alert to Claude and get back a friendly summary."""
    client = _get_client()

    # Trim event payloads so we don't send excessive/raw noise to the model.
    trimmed = {
        "rule": alert.get("rule"),
        "title": alert.get("title"),
        "description": alert.get("description"),
        "event_count": len(alert.get("events", [])),
        "sample_events": alert.get("events", [])[:5],
    }

    response = client.messages.create(
        model=MODEL,
        max_tokens=500,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": json.dumps(trimmed, default=str)}],
    )

    text = "".join(block.text for block in response.content if block.type == "text").strip()
    text = text.removeprefix("```json").removeprefix("```").removesuffix("```").strip()

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {
            "summary": text or "The AI response could not be parsed.",
            "severity": alert.get("severity", "medium"),
            "recommended_action": "Review the raw alert details manually.",
        }


def _ai_summarize_overview(alerts: list) -> str:
    client = _get_client()
    counts = {}
    for a in alerts:
        counts[a.get("rule", "unknown")] = counts.get(a.get("rule", "unknown"), 0) + 1

    response = client.messages.create(
        model=MODEL,
        max_tokens=200,
        system=(
            "You are a security analyst assistant. Write ONE short paragraph (2-4 sentences), "
            "plain English, no markdown, summarizing the overall security posture based on the "
            "alert counts given. Be direct about risk level."
        ),
        messages=[{"role": "user", "content": json.dumps(counts)}],
    )
    return "".join(block.text for block in response.content if block.type == "text").strip()


def _template_overview(alerts: list) -> str:
    high = sum(1 for a in alerts if a.get("severity") in ("high", "critical"))
    medium = sum(1 for a in alerts if a.get("severity") == "medium")
    low = sum(1 for a in alerts if a.get("severity") == "low")
    rules = sorted({a.get("rule", "unknown").replace("_", " ") for a in alerts})
    risk = "high" if high else "medium" if medium else "low"
    return (
        f"This log produced {len(alerts)} alert(s): {high} high, {medium} medium, and {low} low "
        f"severity, covering {', '.join(rules)}. Overall risk level looks {risk} - "
        f"review the high-severity items first."
    )


# ---------------------------------------------------------------------------
# Public functions - these are what the rest of the app calls. They use the
# Claude API automatically when a key is configured, and fall back to the
# built-in templates otherwise. Either way, no request ever fails just
# because a key is missing.
# ---------------------------------------------------------------------------

def summarize_alert(alert: dict) -> dict:
    """Return a friendly summary for one alert - AI-generated if a key is
    configured, otherwise a template-based summary."""
    if not AI_ENABLED:
        return _template_alert_summary(alert)
    try:
        return _ai_summarize_alert(alert)
    except Exception:
        # Any API hiccup (bad key, network issue, rate limit) - fall back
        # gracefully instead of breaking the user's flow.
        return _template_alert_summary(alert)


def summarize_overview(alerts: list) -> str:
    """One short paragraph summarizing the whole batch of alerts for the
    dashboard header - AI-generated if a key is configured, otherwise templated."""
    if not alerts:
        return "No suspicious activity detected in this log file."
    if not AI_ENABLED:
        return _template_overview(alerts)
    try:
        return _ai_summarize_overview(alerts)
    except Exception:
        return _template_overview(alerts)
